// Simplified approach without Tailwind CSS
import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';

// Import pages
import Overview from './pages/Overview';
import TechnologySector from './pages/TechnologySector';
import FinancialServices from './pages/FinancialServices';
import RealEstateDevelopment from './pages/RealEstateDevelopment';
import HealthcareSector from './pages/HealthcareSector';
import PartnershipModels from './pages/PartnershipModels';
import ImpactMetrics from './pages/ImpactMetrics';

// Basic CSS for layout
const styles = {
  app: {
    display: 'flex',
    height: '100vh',
    backgroundColor: '#f3f4f6',
  },
  sidebar: {
    width: '250px',
    backgroundColor: '#1f2937',
    color: 'white',
    padding: '1rem',
  },
  content: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
  },
  header: {
    backgroundColor: 'white',
    padding: '1rem',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
  main: {
    flex: 1,
    padding: '1rem',
    overflowY: 'auto',
  },
  navItem: {
    padding: '0.75rem',
    marginBottom: '0.5rem',
    borderRadius: '0.25rem',
    cursor: 'pointer',
  },
  activeNavItem: {
    backgroundColor: '#3b82f6',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: '0.5rem',
    padding: '1.5rem',
    marginBottom: '1.5rem',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
  },
};

// Simplified Header component
const Header = () => {
  return (
    <header style={styles.header}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
        Corporate Engagement in Domestic Violence Prevention
      </h1>
    </header>
  );
};

// Simplified Sidebar component
const Sidebar = () => {
  const location = window.location.pathname;
  
  const navItems = [
    { path: '/', label: 'Overview' },
    { path: '/technology', label: 'Technology Sector' },
    { path: '/financial', label: 'Financial Services' },
    { path: '/realestate', label: 'Real Estate Development' },
    { path: '/healthcare', label: 'Healthcare Sector' },
    { path: '/partnerships', label: 'Partnership Models' },
    { path: '/impact', label: 'Impact Metrics' },
  ];

  return (
    <aside style={styles.sidebar}>
      <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: '1.5rem' }}>
        Dashboard
      </h2>
      <nav>
        <ul>
          {navItems.map((item) => (
            <li key={item.path}>
              <a 
                href={item.path}
                style={{
                  ...styles.navItem,
                  ...(location === item.path ? styles.activeNavItem : {}),
                  display: 'block',
                  textDecoration: 'none',
                  color: 'white',
                }}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

// Main App component
const App = () => {
  return (
    <Router>
      <div style={styles.app}>
        <Sidebar />
        <div style={styles.content}>
          <Header />
          <main style={styles.main}>
            <Routes>
              <Route path="/" element={<Overview />} />
              <Route path="/technology" element={<TechnologySector />} />
              <Route path="/financial" element={<FinancialServices />} />
              <Route path="/realestate" element={<RealEstateDevelopment />} />
              <Route path="/healthcare" element={<HealthcareSector />} />
              <Route path="/partnerships" element={<PartnershipModels />} />
              <Route path="/impact" element={<ImpactMetrics />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
};

// Render the app
const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App />);

export default App;
