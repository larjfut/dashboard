import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Overview from './pages/Overview';
import TechnologySector from './pages/TechnologySector';
import FinancialServices from './pages/FinancialServices';
import RealEstateDevelopment from './pages/RealEstateDevelopment';
import HealthcareSector from './pages/HealthcareSector';
import PartnershipModels from './pages/PartnershipModels';
import ImpactMetrics from './pages/ImpactMetrics';

function App() {
  return (
    <Router>
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header />
          <main className="flex-1 overflow-y-auto p-4">
            <Routes>
              <Route path="/" element={<Overview />} />
              <Route path="/technology" element={<TechnologySector />} />
              <Route path="/financial" element={<FinancialServices />} />
              <Route path="/realestate" element={<RealEstateDevelopment />} />
              <Route path="/healthcare" element={<HealthcareSector />} />
              <Route path="/partnerships" element={<PartnershipModels />} />
              <Route path="/impact" element={<ImpactMetrics />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;
