import React from 'react';

interface FilterPanelProps {
  sectors: string[];
  partnershipTypes: string[];
  selectedSectors: string[];
  selectedPartnershipTypes: string[];
  showCurrentPartners: boolean;
  showPotentialPartners: boolean;
  onSectorChange: (sector: string) => void;
  onPartnershipTypeChange: (type: string) => void;
  onCurrentPartnersChange: (checked: boolean) => void;
  onPotentialPartnersChange: (checked: boolean) => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
  sectors,
  partnershipTypes,
  selectedSectors,
  selectedPartnershipTypes,
  showCurrentPartners,
  showPotentialPartners,
  onSectorChange,
  onPartnershipTypeChange,
  onCurrentPartnersChange,
  onPotentialPartnersChange
}) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">Filters</h3>
      
      <div className="mb-4">
        <h4 className="font-medium text-gray-700 mb-2">Sectors</h4>
        <div className="space-y-2">
          {sectors.map(sector => (
            <div key={sector} className="flex items-center">
              <input
                type="checkbox"
                id={`sector-${sector}`}
                checked={selectedSectors.includes(sector)}
                onChange={() => onSectorChange(sector)}
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <label htmlFor={`sector-${sector}`} className="ml-2 text-sm text-gray-700">
                {sector}
              </label>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="font-medium text-gray-700 mb-2">Partnership Types</h4>
        <div className="space-y-2">
          {partnershipTypes.map(type => (
            <div key={type} className="flex items-center">
              <input
                type="checkbox"
                id={`type-${type}`}
                checked={selectedPartnershipTypes.includes(type)}
                onChange={() => onPartnershipTypeChange(type)}
                className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
              />
              <label htmlFor={`type-${type}`} className="ml-2 text-sm text-gray-700">
                {type}
              </label>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mb-4">
        <h4 className="font-medium text-gray-700 mb-2">Partner Status</h4>
        <div className="space-y-2">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="current-partners"
              checked={showCurrentPartners}
              onChange={(e) => onCurrentPartnersChange(e.target.checked)}
              className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
            />
            <label htmlFor="current-partners" className="ml-2 text-sm text-gray-700">
              Current Partners
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="potential-partners"
              checked={showPotentialPartners}
              onChange={(e) => onPotentialPartnersChange(e.target.checked)}
              className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
            />
            <label htmlFor="potential-partners" className="ml-2 text-sm text-gray-700">
              Potential Partners
            </label>
          </div>
        </div>
      </div>
      
      <button className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded">
        Reset Filters
      </button>
    </div>
  );
};

export default FilterPanel;
