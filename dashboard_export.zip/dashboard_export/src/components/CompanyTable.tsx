import React from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';

interface CompanyData {
  id: number;
  name: string;
  sector: string;
  status: string; // Changed from literal type to string
  partnershipType: string;
  investment: string;
  impact: string;
}

interface CompanyTableProps {
  data: CompanyData[];
  selectedSectors: string[];
  selectedPartnershipTypes: string[];
  showCurrentPartners: boolean;
  showPotentialPartners: boolean;
}

const CompanyTable: React.FC<CompanyTableProps> = ({
  data,
  selectedSectors,
  selectedPartnershipTypes,
  showCurrentPartners,
  showPotentialPartners
}) => {
  const columns: GridColDef[] = [
    { field: 'name', headerName: 'Company', width: 180 },
    { field: 'sector', headerName: 'Sector', width: 150 },
    { field: 'status', headerName: 'Status', width: 120 },
    { field: 'partnershipType', headerName: 'Partnership Type', width: 180 },
    { field: 'investment', headerName: 'Investment', width: 150 },
    { field: 'impact', headerName: 'Impact', width: 220 },
  ];

  const filteredData = data.filter(company => {
    const sectorMatch = selectedSectors.length === 0 || selectedSectors.includes(company.sector);
    const typeMatch = selectedPartnershipTypes.length === 0 || selectedPartnershipTypes.includes(company.partnershipType);
    
    // Using string comparison instead of literal types
    const statusMatch = 
      (company.status === "current" && showCurrentPartners) || 
      (company.status === "potential" && showPotentialPartners);
    
    return sectorMatch && typeMatch && statusMatch;
  });

  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={filteredData}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        pageSizeOptions={[5, 10]}
        checkboxSelection
      />
    </div>
  );
};

export default CompanyTable;
