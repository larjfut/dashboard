import React from 'react';
import SectorDistribution from '../components/SectorDistribution';
import PartnershipTypeChart from '../components/PartnershipTypeChart';
import CompanyTable from '../components/CompanyTable';

const Overview: React.FC = () => {
  // Sample data for visualizations
  const sectorData = [
    { name: 'Technology', value: 5, color: '#3B82F6' },
    { name: 'Financial', value: 2, color: '#10B981' },
    { name: 'Real Estate', value: 1, color: '#8B5CF6' },
    { name: 'Healthcare', value: 3, color: '#F59E0B' },
  ];

  const partnershipData = [
    { name: 'Financial Contributions', value: 7, color: '#3B82F6' },
    { name: 'Resource Drives', value: 4, color: '#10B981' },
    { name: 'Infrastructure Development', value: 2, color: '#8B5CF6' },
    { name: 'Employee Engagement', value: 5, color: '#F59E0B' },
    { name: 'Strategic Funding', value: 3, color: '#EF4444' },
  ];

  const companyData = [
    {
      id: 1,
      company: 'AM Technical Solutions',
      sector: 'Technology',
      partnershipType: 'Resource Drives',
      status: 'current' as const,
      impact: 'Educational Support',
      details: 'Monthly financial contributions and targeted resource drives'
    },
    {
      id: 2,
      company: 'Texas Capital Bank',
      sector: 'Financial',
      partnershipType: 'Strategic Funding',
      status: 'current' as const,
      impact: 'Housing Solutions',
      details: '$15 million investment in The Sasha supportive housing development'
    },
    {
      id: 3,
      company: 'DMA Development Company',
      sector: 'Real Estate',
      partnershipType: 'Infrastructure Development',
      status: 'current' as const,
      impact: 'Housing Solutions',
      details: 'Lead role in constructing The Sasha complex'
    },
    {
      id: 4,
      company: 'Apple',
      sector: 'Technology',
      partnershipType: 'Financial Contributions',
      status: 'potential' as const,
      impact: 'Community Awareness',
      details: 'Occupies over 2.1 million square feet of office space in Austin'
    },
    {
      id: 5,
      company: 'Dell Technologies',
      sector: 'Technology',
      partnershipType: 'Employee Engagement',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Employs over 17,000 local workers across multiple facilities'
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Corporate Engagement in Domestic Violence Prevention</h2>
        <p className="text-gray-700">
          This dashboard provides an interactive overview of corporate engagement in domestic violence prevention 
          in Austin, highlighting partnerships between local businesses and key service providers like 
          The SAFE Alliance and Texas Council on Family Violence (TCFV).
        </p>
        
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold text-blue-800">11</h3>
            <p className="text-sm text-blue-600">Corporate Partners</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="font-semibold text-green-800">$57M+</h3>
            <p className="text-sm text-green-600">Total Investment</p>
          </div>
          <div className="bg-purple-50 p-4 rounded-lg">
            <h3 className="font-semibold text-purple-800">4</h3>
            <p className="text-sm text-purple-600">Impact Areas</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SectorDistribution data={sectorData} />
        <PartnershipTypeChart data={partnershipData} />
      </div>

      <CompanyTable data={companyData} />

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-bold mb-4">Quick Navigation</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-tech bg-opacity-10 p-4 rounded-lg hover:bg-opacity-20 cursor-pointer">
            <h3 className="font-semibold text-tech">Technology Sector</h3>
            <p className="text-sm text-gray-600">5 companies</p>
          </div>
          <div className="bg-financial bg-opacity-10 p-4 rounded-lg hover:bg-opacity-20 cursor-pointer">
            <h3 className="font-semibold text-financial">Financial Services</h3>
            <p className="text-sm text-gray-600">2 companies</p>
          </div>
          <div className="bg-realestate bg-opacity-10 p-4 rounded-lg hover:bg-opacity-20 cursor-pointer">
            <h3 className="font-semibold text-realestate">Real Estate Development</h3>
            <p className="text-sm text-gray-600">1 company</p>
          </div>
          <div className="bg-healthcare bg-opacity-10 p-4 rounded-lg hover:bg-opacity-20 cursor-pointer">
            <h3 className="font-semibold text-healthcare">Healthcare Sector</h3>
            <p className="text-sm text-gray-600">3 companies</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Overview;
