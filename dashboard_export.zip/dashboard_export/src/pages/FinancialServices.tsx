import React from 'react';
import FilterPanel from '../components/FilterPanel';
import CompanyTable from '../components/CompanyTable';

const FinancialServices: React.FC = () => {
  // Sample data for the Financial Services sector
  const companyData = [
    {
      id: 2,
      company: 'Texas Capital Bank',
      sector: 'Financial',
      partnershipType: 'Strategic Funding',
      status: 'current' as const,
      impact: 'Housing Solutions',
      details: '$15 million investment in The Sasha supportive housing development'
    }
  ];

  // Filter state
  const [selectedSectors, setSelectedSectors] = React.useState<string[]>(['Financial']);
  const [selectedPartnershipTypes, setSelectedPartnershipTypes] = React.useState<string[]>([]);
  const [showCurrentPartners, setShowCurrentPartners] = React.useState(true);
  const [showPotentialPartners, setShowPotentialPartners] = React.useState(true);

  // Filter handlers
  const handleSectorChange = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      setSelectedSectors(selectedSectors.filter(s => s !== sector));
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  const handlePartnershipTypeChange = (type: string) => {
    if (selectedPartnershipTypes.includes(type)) {
      setSelectedPartnershipTypes(selectedPartnershipTypes.filter(t => t !== type));
    } else {
      setSelectedPartnershipTypes([...selectedPartnershipTypes, type]);
    }
  };

  // Filter the data based on selected filters
  const filteredData = companyData.filter(company => {
    const sectorMatch = selectedSectors.length === 0 || selectedSectors.includes(company.sector);
    const typeMatch = selectedPartnershipTypes.length === 0 || selectedPartnershipTypes.includes(company.partnershipType);
    const statusMatch = (company.status === 'current' && showCurrentPartners) || 
                        (company.status === 'potential' && showPotentialPartners);
    
    return sectorMatch && typeMatch && statusMatch;
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Financial Services Leadership</h2>
        <p className="text-gray-700">
          Financial institutions play a crucial role in domestic violence prevention through strategic funding
          partnerships that address key infrastructure needs for survivors, such as housing solutions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <FilterPanel 
            sectors={['Technology', 'Financial', 'Real Estate', 'Healthcare']}
            partnershipTypes={['Resource Drives', 'Financial Contributions', 'Employee Engagement', 'Strategic Funding']}
            selectedSectors={selectedSectors}
            selectedPartnershipTypes={selectedPartnershipTypes}
            showCurrentPartners={showCurrentPartners}
            showPotentialPartners={showPotentialPartners}
            onSectorChange={handleSectorChange}
            onPartnershipTypeChange={handlePartnershipTypeChange}
            onCurrentPartnersChange={setShowCurrentPartners}
            onPotentialPartnersChange={setShowPotentialPartners}
          />
        </div>
        
        <div className="lg:col-span-3">
          <CompanyTable data={filteredData} />
          
          <div className="mt-6 bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">Texas Capital Bank: Strategic Funding Partnerships</h3>
            <p className="text-gray-700 mb-4">
              As primary financial partner for The Sasha supportive housing development, Texas Capital Bank
              plays a pivotal role in addressing the intersection of domestic violence and homelessness.
              The bank's $15 million investment in this 60-unit complex enables SAFE Alliance to provide
              transitional and permanent housing solutions for survivors, directly addressing one of the most
              significant barriers to escaping abusive situations - lack of safe, affordable housing.
            </p>
            <p className="text-gray-700">
              The bank's involvement extends beyond conventional philanthropy, incorporating financial
              expertise into project development through risk assessment and sustainable funding models.
              This partnership demonstrates how financial institutions can leverage both capital and technical
              expertise to create systemic solutions for domestic violence survivors.
            </p>
            
            <div className="mt-6 bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-800 mb-2">Key Impact Metrics</h4>
              <ul className="list-disc pl-5 space-y-2 text-blue-700">
                <li>$15 million investment in supportive housing</li>
                <li>60-unit housing complex for survivors</li>
                <li>Addresses housing insecurity for domestic violence survivors</li>
                <li>Provides both transitional and permanent housing solutions</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialServices;
