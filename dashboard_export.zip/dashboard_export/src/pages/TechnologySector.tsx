import React from 'react';
import FilterPanel from '../components/FilterPanel';
import CompanyTable from '../components/CompanyTable';

const TechnologySector: React.FC = () => {
  // Sample data for the Technology sector
  const companyData = [
    {
      id: 1,
      company: 'AM Technical Solutions',
      sector: 'Technology',
      partnershipType: 'Resource Drives',
      status: 'current' as const,
      impact: 'Educational Support',
      details: 'Monthly financial contributions and targeted resource drives'
    },
    {
      id: 4,
      company: 'Apple',
      sector: 'Technology',
      partnershipType: 'Financial Contributions',
      status: 'potential' as const,
      impact: 'Community Awareness',
      details: 'Occupies over 2.1 million square feet of office space in Austin'
    },
    {
      id: 5,
      company: 'Dell Technologies',
      sector: 'Technology',
      partnershipType: 'Employee Engagement',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Employs over 17,000 local workers across multiple facilities'
    },
    {
      id: 6,
      company: 'IBM',
      sector: 'Technology',
      partnershipType: 'Strategic Funding',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Over 6,200 local employees and 1.4 million square feet of office space'
    },
    {
      id: 7,
      company: 'Meta',
      sector: 'Technology',
      partnershipType: 'Community Awareness',
      status: 'potential' as const,
      impact: 'Community Awareness',
      details: 'Occupies over 778,000 square feet of office space in Austin'
    },
    {
      id: 8,
      company: 'Oracle',
      sector: 'Technology',
      partnershipType: 'Data Analytics',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Maintains significant Austin operations with over 550,000 square feet of office space'
    }
  ];

  // Filter state
  const [selectedSectors, setSelectedSectors] = React.useState<string[]>(['Technology']);
  const [selectedPartnershipTypes, setSelectedPartnershipTypes] = React.useState<string[]>([]);
  const [showCurrentPartners, setShowCurrentPartners] = React.useState(true);
  const [showPotentialPartners, setShowPotentialPartners] = React.useState(true);

  // Filter handlers
  const handleSectorChange = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      setSelectedSectors(selectedSectors.filter(s => s !== sector));
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  const handlePartnershipTypeChange = (type: string) => {
    if (selectedPartnershipTypes.includes(type)) {
      setSelectedPartnershipTypes(selectedPartnershipTypes.filter(t => t !== type));
    } else {
      setSelectedPartnershipTypes([...selectedPartnershipTypes, type]);
    }
  };

  // Filter the data based on selected filters
  const filteredData = companyData.filter(company => {
    const sectorMatch = selectedSectors.length === 0 || selectedSectors.includes(company.sector);
    const typeMatch = selectedPartnershipTypes.length === 0 || selectedPartnershipTypes.includes(company.partnershipType);
    const statusMatch = (company.status === 'current' && showCurrentPartners) || 
                        (company.status === 'potential' && showPotentialPartners);
    
    return sectorMatch && typeMatch && statusMatch;
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Technology Sector Engagement</h2>
        <p className="text-gray-700">
          The technology sector demonstrates significant engagement in domestic violence prevention in Austin,
          with both current active partners like AM Technical Solutions and potential strategic partners
          including major companies like Apple, Dell, IBM, Meta, and Oracle.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <FilterPanel 
            sectors={['Technology', 'Financial', 'Real Estate', 'Healthcare']}
            partnershipTypes={['Resource Drives', 'Financial Contributions', 'Employee Engagement', 'Strategic Funding', 'Community Awareness', 'Data Analytics']}
            selectedSectors={selectedSectors}
            selectedPartnershipTypes={selectedPartnershipTypes}
            showCurrentPartners={showCurrentPartners}
            showPotentialPartners={showPotentialPartners}
            onSectorChange={handleSectorChange}
            onPartnershipTypeChange={handlePartnershipTypeChange}
            onCurrentPartnersChange={setShowCurrentPartners}
            onPotentialPartnersChange={setShowPotentialPartners}
          />
        </div>
        
        <div className="lg:col-span-3">
          <CompanyTable data={filteredData} />
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Current Partners</h3>
              <div className="space-y-4">
                <div className="border-l-4 border-green-500 pl-4">
                  <h4 className="font-medium">AM Technical Solutions</h4>
                  <p className="text-sm text-gray-600">
                    Provides monthly financial contributions and targeted resource drives to The SAFE Alliance.
                    Their 2024 back-to-school initiative delivered essential educational supplies to children in SAFE's care.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Potential Partners</h3>
              <div className="space-y-4">
                <div className="border-l-4 border-blue-500 pl-4">
                  <h4 className="font-medium">Apple</h4>
                  <p className="text-sm text-gray-600">
                    Occupies over 2.1 million square feet of office space in Austin, with established CSR programs
                    focusing on human rights and community safety.
                  </p>
                </div>
                <div className="border-l-4 border-blue-500 pl-4">
                  <h4 className="font-medium">Dell Technologies</h4>
                  <p className="text-sm text-gray-600">
                    Employs over 17,000 local workers across multiple facilities and maintains its global headquarters
                    in nearby Round Rock with over 13,000 employees.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnologySector;
