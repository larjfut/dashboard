import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import FilterPanel from '../components/FilterPanel';

const ImpactMetrics: React.FC = () => {
  // Sample data for impact metrics
  const housingImpactData = [
    { year: '2020', units: 20 },
    { year: '2021', units: 35 },
    { year: '2022', units: 45 },
    { year: '2023', units: 52 },
    { year: '2024', units: 60 },
  ];

  const educationalSupportData = [
    { year: '2020', children: 120 },
    { year: '2021', children: 175 },
    { year: '2022', children: 210 },
    { year: '2023', children: 250 },
    { year: '2024', children: 300 },
  ];

  // Filter state
  const [selectedImpactAreas, setSelectedImpactAreas] = React.useState<string[]>([]);
  const [selectedSectors, setSelectedSectors] = React.useState<string[]>([]);

  // Filter handlers
  const handleImpactAreaChange = (area: string) => {
    if (selectedImpactAreas.includes(area)) {
      setSelectedImpactAreas(selectedImpactAreas.filter(a => a !== area));
    } else {
      setSelectedImpactAreas([...selectedImpactAreas, area]);
    }
  };

  const handleSectorChange = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      setSelectedSectors(selectedSectors.filter(s => s !== sector));
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Impact Metrics</h2>
        <p className="text-gray-700">
          This page provides metrics and visualizations of the impact of corporate engagement in
          domestic violence prevention across different areas, including housing solutions,
          educational support, community awareness, and service delivery enhancement.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white p-4 rounded-lg shadow-md mb-6">
            <h3 className="text-lg font-semibold mb-4">Impact Areas</h3>
            <div className="space-y-2">
              {['Housing Solutions', 'Educational Support', 'Community Awareness', 'Service Delivery'].map(area => (
                <div key={area} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`area-${area}`}
                    checked={selectedImpactAreas.includes(area)}
                    onChange={() => handleImpactAreaChange(area)}
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                  />
                  <label htmlFor={`area-${area}`} className="ml-2 text-sm text-gray-700">
                    {area}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">Corporate Sectors</h3>
            <div className="space-y-2">
              {['Technology', 'Financial', 'Real Estate', 'Healthcare'].map(sector => (
                <div key={sector} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`sector-${sector}`}
                    checked={selectedSectors.includes(sector)}
                    onChange={() => handleSectorChange(sector)}
                    className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                  />
                  <label htmlFor={`sector-${sector}`} className="ml-2 text-sm text-gray-700">
                    {sector}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Housing Solutions Impact</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={housingImpactData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="units" name="Housing Units" stroke="#8B5CF6" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 bg-purple-50 p-3 rounded-lg">
                <p className="text-sm text-purple-700">
                  Housing units provided for domestic violence survivors have increased by 200% since 2020,
                  primarily through partnerships with financial institutions and real estate developers.
                </p>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Educational Support Impact</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={educationalSupportData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="children" name="Children Supported" stroke="#3B82F6" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-700">
                  Educational support programs have reached 300 children in 2024, a 150% increase from 2020,
                  primarily through technology sector partnerships and resource drives.
                </p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Community Awareness Impact</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div className="bg-green-500 h-4 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                  <span className="ml-2 text-sm font-medium">75%</span>
                </div>
                <p className="text-sm text-gray-600">
                  Increase in community awareness of domestic violence resources since the launch of
                  corporate partnership campaigns.
                </p>
                
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div className="bg-green-500 h-4 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                  <span className="ml-2 text-sm font-medium">60%</span>
                </div>
                <p className="text-sm text-gray-600">
                  Increase in calls to domestic violence hotlines following awareness campaigns
                  supported by corporate partners.
                </p>
                
                <div className="flex items-center">
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div className="bg-green-500 h-4 rounded-full" style={{ width: '45%' }}></div>
                  </div>
                  <span className="ml-2 text-sm font-medium">45%</span>
                </div>
                <p className="text-sm text-gray-600">
                  Increase in workplace domestic violence awareness training participation.
                </p>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Service Delivery Enhancement</h3>
              <div className="space-y-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <h4 className="font-medium">Technology Infrastructure</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Corporate technology partnerships have enabled a 40% increase in service delivery
                    efficiency through improved case management systems and digital resources.
                  </p>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <h4 className="font-medium">Professional Services</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Pro bono professional services from corporate partners have provided an estimated
                    $1.2 million in value to domestic violence prevention organizations.
                  </p>
                </div>
                
                <div className="p-3 bg-gray-50 rounded-lg">
                  <h4 className="font-medium">Volunteer Hours</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Corporate volunteer programs have contributed over 5,000 hours to domestic violence
                    prevention efforts in the past year.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImpactMetrics;
