import React from 'react';
import FilterPanel from '../components/FilterPanel';
import CompanyTable from '../components/CompanyTable';

const HealthcareSector: React.FC = () => {
  // Sample data for the Healthcare sector
  const companyData = [
    {
      id: 9,
      company: 'Ascension Seton',
      sector: 'Healthcare',
      partnershipType: 'Service Provision',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Largest healthcare provider in Austin with extensive community programs'
    },
    {
      id: 10,
      company: 'St. David\'s HealthCare',
      sector: 'Healthcare',
      partnershipType: 'Community Awareness',
      status: 'potential' as const,
      impact: 'Community Awareness',
      details: 'Major healthcare system with established community outreach programs'
    },
    {
      id: 11,
      company: 'Baylor Scott & White Health',
      sector: 'Healthcare',
      partnershipType: 'Financial Contributions',
      status: 'potential' as const,
      impact: 'Service Delivery',
      details: 'Growing presence in Austin with strong corporate social responsibility focus'
    }
  ];

  // Filter state
  const [selectedSectors, setSelectedSectors] = React.useState<string[]>(['Healthcare']);
  const [selectedPartnershipTypes, setSelectedPartnershipTypes] = React.useState<string[]>([]);
  const [showCurrentPartners, setShowCurrentPartners] = React.useState(true);
  const [showPotentialPartners, setShowPotentialPartners] = React.useState(true);

  // Filter handlers
  const handleSectorChange = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      setSelectedSectors(selectedSectors.filter(s => s !== sector));
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  const handlePartnershipTypeChange = (type: string) => {
    if (selectedPartnershipTypes.includes(type)) {
      setSelectedPartnershipTypes(selectedPartnershipTypes.filter(t => t !== type));
    } else {
      setSelectedPartnershipTypes([...selectedPartnershipTypes, type]);
    }
  };

  // Filter the data based on selected filters
  const filteredData = companyData.filter(company => {
    const sectorMatch = selectedSectors.length === 0 || selectedSectors.includes(company.sector);
    const typeMatch = selectedPartnershipTypes.length === 0 || selectedPartnershipTypes.includes(company.partnershipType);
    const statusMatch = (company.status === 'current' && showCurrentPartners) || 
                        (company.status === 'potential' && showPotentialPartners);
    
    return sectorMatch && typeMatch && statusMatch;
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Healthcare Sector Partners</h2>
        <p className="text-gray-700">
          Healthcare organizations represent significant potential partners for domestic violence prevention
          efforts, with their extensive community reach, established screening protocols, and ability to
          identify and support survivors through healthcare interactions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <FilterPanel 
            sectors={['Technology', 'Financial', 'Real Estate', 'Healthcare']}
            partnershipTypes={['Service Provision', 'Community Awareness', 'Financial Contributions', 'Employee Engagement']}
            selectedSectors={selectedSectors}
            selectedPartnershipTypes={selectedPartnershipTypes}
            showCurrentPartners={showCurrentPartners}
            showPotentialPartners={showPotentialPartners}
            onSectorChange={handleSectorChange}
            onPartnershipTypeChange={handlePartnershipTypeChange}
            onCurrentPartnersChange={setShowCurrentPartners}
            onPotentialPartnersChange={setShowPotentialPartners}
          />
        </div>
        
        <div className="lg:col-span-3">
          <CompanyTable data={filteredData} />
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Potential Healthcare Partnerships</h3>
              <p className="text-gray-700 mb-4">
                Healthcare providers are uniquely positioned to identify and support domestic violence
                survivors through regular patient interactions and established screening protocols.
              </p>
              <div className="space-y-4">
                <div className="border-l-4 border-orange-500 pl-4">
                  <h4 className="font-medium">Ascension Seton</h4>
                  <p className="text-sm text-gray-600">
                    As the largest healthcare provider in Austin, Ascension Seton has extensive community
                    programs that could be leveraged for domestic violence prevention and survivor support.
                  </p>
                </div>
                <div className="border-l-4 border-orange-500 pl-4">
                  <h4 className="font-medium">St. David's HealthCare</h4>
                  <p className="text-sm text-gray-600">
                    With established community outreach programs, St. David's could integrate domestic
                    violence awareness and screening into their existing healthcare delivery model.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">Partnership Opportunities</h3>
              <div className="space-y-4">
                <div className="p-3 bg-orange-50 rounded-lg">
                  <h4 className="font-medium text-orange-800">Screening Integration</h4>
                  <p className="text-sm text-orange-700">
                    Implement domestic violence screening protocols across healthcare facilities to
                    identify survivors and connect them with appropriate resources.
                  </p>
                </div>
                <div className="p-3 bg-orange-50 rounded-lg">
                  <h4 className="font-medium text-orange-800">Provider Training</h4>
                  <p className="text-sm text-orange-700">
                    Develop training programs for healthcare providers on recognizing signs of domestic
                    violence and appropriate intervention strategies.
                  </p>
                </div>
                <div className="p-3 bg-orange-50 rounded-lg">
                  <h4 className="font-medium text-orange-800">Resource Coordination</h4>
                  <p className="text-sm text-orange-700">
                    Create direct referral pathways between healthcare facilities and domestic violence
                    service providers to streamline access to support services.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthcareSector;
