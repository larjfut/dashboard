import React from 'react';
import FilterPanel from '../components/FilterPanel';
import CompanyTable from '../components/CompanyTable';

const RealEstateDevelopment: React.FC = () => {
  // Sample data for the Real Estate sector
  const companyData = [
    {
      id: 3,
      company: 'DMA Development Company',
      sector: 'Real Estate',
      partnershipType: 'Infrastructure Development',
      status: 'current' as const,
      impact: 'Housing Solutions',
      details: 'Lead role in constructing The Sasha complex'
    }
  ];

  // Filter state
  const [selectedSectors, setSelectedSectors] = React.useState<string[]>(['Real Estate']);
  const [selectedPartnershipTypes, setSelectedPartnershipTypes] = React.useState<string[]>([]);
  const [showCurrentPartners, setShowCurrentPartners] = React.useState(true);
  const [showPotentialPartners, setShowPotentialPartners] = React.useState(true);

  // Filter handlers
  const handleSectorChange = (sector: string) => {
    if (selectedSectors.includes(sector)) {
      setSelectedSectors(selectedSectors.filter(s => s !== sector));
    } else {
      setSelectedSectors([...selectedSectors, sector]);
    }
  };

  const handlePartnershipTypeChange = (type: string) => {
    if (selectedPartnershipTypes.includes(type)) {
      setSelectedPartnershipTypes(selectedPartnershipTypes.filter(t => t !== type));
    } else {
      setSelectedPartnershipTypes([...selectedPartnershipTypes, type]);
    }
  };

  // Filter the data based on selected filters
  const filteredData = companyData.filter(company => {
    const sectorMatch = selectedSectors.length === 0 || selectedSectors.includes(company.sector);
    const typeMatch = selectedPartnershipTypes.length === 0 || selectedPartnershipTypes.includes(company.partnershipType);
    const statusMatch = (company.status === 'current' && showCurrentPartners) || 
                        (company.status === 'potential' && showPotentialPartners);
    
    return sectorMatch && typeMatch && statusMatch;
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Real Estate Development Commitments</h2>
        <p className="text-gray-700">
          Real estate developers play a crucial role in creating physical infrastructure for survivor support,
          addressing one of the most significant barriers to escaping domestic violence situations - lack of
          safe, affordable housing.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <FilterPanel 
            sectors={['Technology', 'Financial', 'Real Estate', 'Healthcare']}
            partnershipTypes={['Resource Drives', 'Financial Contributions', 'Infrastructure Development', 'Strategic Funding']}
            selectedSectors={selectedSectors}
            selectedPartnershipTypes={selectedPartnershipTypes}
            showCurrentPartners={showCurrentPartners}
            showPotentialPartners={showPotentialPartners}
            onSectorChange={handleSectorChange}
            onPartnershipTypeChange={handlePartnershipTypeChange}
            onCurrentPartnersChange={setShowCurrentPartners}
            onPotentialPartnersChange={setShowPotentialPartners}
          />
        </div>
        
        <div className="lg:col-span-3">
          <CompanyTable data={filteredData} />
          
          <div className="mt-6 bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">DMA Development Company: Infrastructure Solutions</h3>
            <p className="text-gray-700 mb-4">
              DMA Development Company emerges as a critical partner in creating physical infrastructure for
              survivor support through their lead role in constructing The Sasha complex. The developer's
              collaboration with SAFE Alliance represents a $42 million investment in trauma-informed design,
              incorporating security features and community spaces that specifically address survivor needs.
            </p>
            <p className="text-gray-700">
              This project establishes new standards for housing developments targeting vulnerable
              populations, with architectural plans including secure entry systems and on-site counseling
              facilities. The company's partnership model combines construction management with long-term
              operational planning, ensuring the housing complex maintains functionality for its intended
              population.
            </p>
            
            <div className="mt-6 bg-purple-50 p-4 rounded-lg">
              <h4 className="font-medium text-purple-800 mb-2">Key Impact Metrics</h4>
              <ul className="list-disc pl-5 space-y-2 text-purple-700">
                <li>$42 million investment in trauma-informed housing design</li>
                <li>60-unit complex with security features for survivors</li>
                <li>On-site counseling facilities and community spaces</li>
                <li>Long-term operational planning for sustained impact</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RealEstateDevelopment;
