import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const partnershipData = [
  { name: 'Financial Contributions', current: 2, potential: 5 },
  { name: 'Resource Drives', current: 1, potential: 3 },
  { name: 'Infrastructure Development', current: 1, potential: 2 },
  { name: 'Employee Engagement', current: 1, potential: 4 },
  { name: 'Strategic Funding', current: 1, potential: 2 },
];

const PartnershipModels: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Partnership Models</h2>
        <p className="text-gray-700 mb-4">
          Corporate engagement in domestic violence prevention takes many forms, from financial contributions 
          to resource drives, infrastructure development, and employee engagement programs. This page explores 
          the different partnership models and their impact.
        </p>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-bold mb-4">Partnership Types Overview</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={partnershipData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="current" name="Current Partners" fill="#22C55E" />
              <Bar dataKey="potential" name="Potential Partners" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold mb-4">Financial Contribution Models</h3>
          <p className="text-gray-700 mb-4">
            Financial contributions provide essential funding for domestic violence prevention and support services.
          </p>
          <div className="space-y-4">
            <div className="border-l-4 border-primary pl-4 py-2">
              <h4 className="font-semibold">Direct Monetary Support</h4>
              <p className="text-gray-600">
                Regular financial contributions to organizations like The SAFE Alliance and TCFV, 
                supporting operational costs and program development.
              </p>
            </div>
            <div className="border-l-4 border-primary pl-4 py-2">
              <h4 className="font-semibold">Project-Based Funding</h4>
              <p className="text-gray-600">
                Targeted investments in specific initiatives, such as Texas Capital Bank's 
                $15 million investment in The Sasha supportive housing development.
              </p>
            </div>
            <div className="border-l-4 border-primary pl-4 py-2">
              <h4 className="font-semibold">Corporate Foundation Grants</h4>
              <p className="text-gray-600">
                Structured grant programs that provide funding for specific domestic violence 
                prevention programs and research initiatives.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold mb-4">Resource and Service Provision</h3>
          <p className="text-gray-700 mb-4">
            Companies provide essential resources and services to support domestic violence survivors.
          </p>
          <div className="space-y-4">
            <div className="border-l-4 border-secondary pl-4 py-2">
              <h4 className="font-semibold">Resource Drives</h4>
              <p className="text-gray-600">
                Collection and donation of essential supplies, such as AM Technical Solutions' 
                back-to-school initiative providing educational supplies to children in SAFE's care.
              </p>
            </div>
            <div className="border-l-4 border-secondary pl-4 py-2">
              <h4 className="font-semibold">Pro Bono Services</h4>
              <p className="text-gray-600">
                Professional services provided at no cost, such as legal assistance, 
                financial planning, or technology support for survivors.
              </p>
            </div>
            <div className="border-l-4 border-secondary pl-4 py-2">
              <h4 className="font-semibold">Technical Expertise</h4>
              <p className="text-gray-600">
                Specialized knowledge and skills shared with service providers, 
                such as data analytics or technology solutions to enhance program effectiveness.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold mb-4">Infrastructure Development</h3>
          <p className="text-gray-700 mb-4">
            Creating physical infrastructure to support domestic violence survivors.
          </p>
          <div className="space-y-4">
            <div className="border-l-4 border-accent pl-4 py-2">
              <h4 className="font-semibold">Housing Development</h4>
              <p className="text-gray-600">
                Construction of safe, affordable housing for survivors, such as DMA Development 
                Company's lead role in constructing The Sasha complex.
              </p>
            </div>
            <div className="border-l-4 border-accent pl-4 py-2">
              <h4 className="font-semibold">Facility Improvements</h4>
              <p className="text-gray-600">
                Renovations and upgrades to existing shelters and service centers to 
                enhance safety, comfort, and functionality.
              </p>
            </div>
            <div className="border-l-4 border-accent pl-4 py-2">
              <h4 className="font-semibold">Technology Infrastructure</h4>
              <p className="text-gray-600">
                Development of digital platforms and systems to improve service delivery 
                and coordination among providers.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-bold mb-4">Employee Engagement Programs</h3>
          <p className="text-gray-700 mb-4">
            Mobilizing corporate workforce to support domestic violence prevention efforts.
          </p>
          <div className="space-y-4">
            <div className="border-l-4 border-healthcare pl-4 py-2">
              <h4 className="font-semibold">Volunteer Programs</h4>
              <p className="text-gray-600">
                Organized opportunities for employees to volunteer with domestic violence 
                service providers, contributing time and skills.
              </p>
            </div>
            <div className="border-l-4 border-healthcare pl-4 py-2">
              <h4 className="font-semibold">Workplace Awareness Campaigns</h4>
              <p className="text-gray-600">
                Educational initiatives within companies to raise awareness about domestic 
                violence and available resources.
              </p>
            </div>
            <div className="border-l-4 border-healthcare pl-4 py-2">
              <h4 className="font-semibold">Matching Gift Programs</h4>
              <p className="text-gray-600">
                Corporate matching of employee donations to domestic violence prevention 
                organizations, amplifying individual contributions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PartnershipModels;
